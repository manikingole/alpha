package com.example.MappingsSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MappingsSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
